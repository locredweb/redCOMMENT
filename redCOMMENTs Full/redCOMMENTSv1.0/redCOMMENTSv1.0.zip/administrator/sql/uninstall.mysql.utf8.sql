DROP TABLE IF EXISTS `#__redcomments_discussions`;
DROP TABLE IF EXISTS `#__redcomments_comments`;
DROP TABLE IF EXISTS `#__redcomments_subscriptions`;
DROP TABLE IF EXISTS `#__redcomments_notifications`;
